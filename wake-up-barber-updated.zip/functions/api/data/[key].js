// Cloudflare Pages Function — tiny shared storage API used by index.html
// Route: /api/data/:key  (e.g. /api/data/wub_bookings)
//
// Requires a KV namespace bound to this Pages project as "WUB_KV".
// See README.txt for the one-time setup steps.

const ALLOWED_KEYS = new Set([
  "wub_settings",
  "wub_bookings",
  "wub_blocked",
  "wub_closedDates"
]);

function corsHeaders() {
  return {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET,POST,OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type"
  };
}

export async function onRequestOptions() {
  return new Response(null, { headers: corsHeaders() });
}

export async function onRequestGet(context) {
  const { params, env } = context;
  const key = params.key;

  if (!ALLOWED_KEYS.has(key)) {
    return new Response(JSON.stringify({ error: "unknown key" }), {
      status: 400,
      headers: { "Content-Type": "application/json", ...corsHeaders() }
    });
  }
  if (!env.WUB_KV) {
    return new Response(JSON.stringify({ error: "KV namespace not bound. See README.txt." }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders() }
    });
  }

  const value = await env.WUB_KV.get(key);
  return new Response(value === null ? "null" : value, {
    headers: { "Content-Type": "application/json", ...corsHeaders() }
  });
}

export async function onRequestPost(context) {
  const { params, env, request } = context;
  const key = params.key;

  if (!ALLOWED_KEYS.has(key)) {
    return new Response(JSON.stringify({ error: "unknown key" }), {
      status: 400,
      headers: { "Content-Type": "application/json", ...corsHeaders() }
    });
  }
  if (!env.WUB_KV) {
    return new Response(JSON.stringify({ error: "KV namespace not bound. See README.txt." }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders() }
    });
  }

  const bodyText = await request.text();
  // Validate it's real JSON before saving.
  try {
    JSON.parse(bodyText);
  } catch (e) {
    return new Response(JSON.stringify({ error: "invalid json" }), {
      status: 400,
      headers: { "Content-Type": "application/json", ...corsHeaders() }
    });
  }

  await env.WUB_KV.put(key, bodyText);
  return new Response(JSON.stringify({ ok: true }), {
    headers: { "Content-Type": "application/json", ...corsHeaders() }
  });
}
