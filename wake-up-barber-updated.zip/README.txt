WAKE UP BARBER — DEPLOY TO CLOUDFLARE PAGES
=============================================

WHAT'S IN THIS FOLDER
  index.html    the whole site (booking page + barber dashboard)
  assets/       logo + hero animation
  functions/    the backend that saves bookings (Cloudflare Pages Function)
  _headers      caching rules for the video/logo

STEP 1 — Upload the site
  Cloudflare dashboard → Workers & Pages → Create → Pages → Upload assets.
  Upload the CONTENTS of this folder (or the zip directly).
  index.html must stay at the root, next to the assets/ and functions/ folders.

STEP 2 — Turn on the storage (REQUIRED — do this or bookings won't save)
  This site needs a small database so a booking a client makes on their
  phone shows up on the barber's phone too. Cloudflare's free "KV" storage
  does that job. One-time setup:

  1. In the Cloudflare dashboard: Storage & Databases → KV → Create a namespace.
     Name it anything, e.g. "wake-up-barber-data".
  2. Go to your Pages project → Settings → Functions → KV namespace bindings
     → Add binding.
       Variable name:   WUB_KV        (must be exactly this)
       KV namespace:    the one you just created
  3. Do this for BOTH the "Production" and "Preview" environments.
  4. Re-deploy the site once (Deployments → ⋯ → Retry deployment, or just
     re-upload) so the binding takes effect.

  That's it — after this, bookings made on the live site are shared
  between every client and the barber's dashboard automatically.

  If you skip this step, the site still loads and looks normal, but
  nothing will save — every booking disappears on refresh.

MAIN PAGE:      index.html
BARBER LOGIN:   scroll to the footer → "Barber login" (default PIN 1234 —
                change it under Dashboard → Settings once you're in)
ANIMATION:      assets/wakeupbarbershop.mp4
LOGO:           assets/wakeupbarber-logo-transparent.png
